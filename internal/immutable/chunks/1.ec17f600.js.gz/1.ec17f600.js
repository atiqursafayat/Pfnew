import{default as t}from"../entry/error.svelte.0944b4d9.js";export{t as component};
