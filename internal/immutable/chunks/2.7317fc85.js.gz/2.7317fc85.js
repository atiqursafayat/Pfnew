import{default as t}from"../entry/_page.svelte.6ca4e389.js";export{t as component};
