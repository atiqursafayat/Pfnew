import{default as t}from"../entry/error.svelte.878f0fba.js";export{t as component};
