import{default as t}from"../entry/error.svelte.04e926ca.js";export{t as component};
