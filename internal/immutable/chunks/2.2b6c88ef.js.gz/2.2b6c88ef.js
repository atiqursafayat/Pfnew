import{default as t}from"../entry/_page.svelte.d7d4de67.js";export{t as component};
