import{default as t}from"../entry/_page.svelte.9f072c31.js";export{t as component};
