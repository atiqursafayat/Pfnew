import{default as t}from"../entry/_page.svelte.348ed332.js";export{t as component};
