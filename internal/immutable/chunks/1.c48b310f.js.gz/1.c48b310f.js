import{default as t}from"../entry/error.svelte.81175bcf.js";export{t as component};
