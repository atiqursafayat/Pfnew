import{default as t}from"../entry/error.svelte.9a643821.js";export{t as component};
