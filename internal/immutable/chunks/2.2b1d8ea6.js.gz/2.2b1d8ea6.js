import{default as t}from"../entry/_page.svelte.d1ed98d4.js";export{t as component};
