import{default as t}from"../entry/error.svelte.2ae6e795.js";export{t as component};
