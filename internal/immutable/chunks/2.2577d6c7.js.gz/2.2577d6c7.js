import{default as t}from"../entry/_page.svelte.e1b6afc7.js";export{t as component};
