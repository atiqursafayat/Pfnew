import{default as t}from"../entry/error.svelte.3f7dcfe7.js";export{t as component};
