import{default as t}from"../entry/error.svelte.50a85749.js";export{t as component};
